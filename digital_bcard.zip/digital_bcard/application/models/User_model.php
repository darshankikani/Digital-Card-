<?php
class User_model extends CI_model{

    public function new_register_user(){
        $username=$this->input->post('u_name');
        $email=$this->input->post('email');
        $password=$this->input->post('password');
        $data = array(
              'u_name ' => $username,
              'email' => $email,
              'password' => $password
         );
        $this->db->insert('user',$data);
        return $data;
    }

    public function login_user($email,$pass){
      $this->db->select('u_id,u_name,email');
      $this->db->from('user');
      $this->db->where('email',$email);
      $this->db->where('password',$pass);
      if($query=$this->db->get()){
          return $query->row_array();
      }
      else{
        return false;
      }
    }

    public function getUser($id){
      $query = $this->db->get_where('user',array('u_id'=>$id));
      return $query->row_array();
    }

    public function updateuser($user, $id){
      $this->db->where('user.u_id', $id);
      return $this->db->update('user', $user);
    }

    public function view_card1($c_id){
      $query = $this->db->get_where('card',array('c_id'=>$c_id,'u_id'=>$_SESSION['u_id']));
      $query=(array)$query->row_array();
      $this->db->select('m_number');
      $this->db->from('mob_number');
      $this->db->where('c_id',$c_id);
      if($query1=$this->db->get()){
          $n=$query1->num_rows();
          if($n==1){
            $m1=(array)$query1->first_row();
             if(isset($m1)){
              $m1=$m1['m_number'];
             }
             $m2="";
             $m3="";
             $key=array('m1','m2','m3');
             $value=array($m1,$m2,$m3);
             $a=array_combine($key, $value);
             return array_merge($query,$a);
          }
          else if($n==2){
            $m1=(array)$query1->first_row();
             if(isset($m1)){
              $m1=$m1['m_number'];
             }
             $m2=(array)$query1->next_row();
             if(isset($m2)){
                $m2=$m2['m_number'];
             }
             $m3="";
             $key=array('m1','m2','m3');
             $value=array($m1,$m2,$m3);
             $a=array_combine($key, $value);
             return array_merge($query,$a);
          }
          else if($n==3){
            $m1=(array)$query1->first_row();
             if(isset($m1)){
              $m1=$m1['m_number'];
             }
             $m2=(array)$query1->next_row();
             if(isset($m2)){
                $m2=$m2['m_number'];
             }
             $m3=(array)$query1->next_row();
             if(isset($m3)){
                $m3=$m3['m_number'];
             }
             $key=array('m1','m2','m3');
             $value=array($m1,$m2,$m3);
             $a=array_combine($key, $value);
             return array_merge($query,$a);
          } 
          else{
             $m1="";
             $m2="";
             $m3="";
             $key=array('m1','m2','m3');
             $value=array($m1,$m2,$m3);
             $a=array_combine($key, $value);
             return array_merge($query,$a);
          } 
      }
      else{
        return false;
      }
    }

    public function fetch_card(){
      $this->db->select('*');
      $this->db->from('ucard');
      $this->db->where('status',0);
      if($query=$this->db->get()){
          return $query->result();
      }
      else{
        return false;
      }
    }

    public function appcard(){
      $this->db->select('*');
      $this->db->from('ucard');
      $this->db->where('status',1);
      if($query=$this->db->get()){
          return $query->result();
      }
      else{
        return false;
      }
    }

    public function view_card(){
      $this->db->select('c_id,card_d_name');
      $this->db->from('card');
      $this->db->where('u_id',$_SESSION['u_id']);
      if($query=$this->db->get()){
          return $query->result();
      }
      else{
        return false;
      }
    }

    public function view_card11($c_id){
      $this->db->select('card_d_name');
      $this->db->from('card');
      $this->db->where('c_id',$c_id);
      if($query=$this->db->get()){
          return $query->result();
      }
      else{
        return false;
      }
    }

    public function view_card12($c_id){
      $query = $this->db->get_where('card',array('c_id'=>$c_id,'u_id'=>$_SESSION['u_id']));
      $query=(array)$query->row_array();
      $this->db->select('m_number');
      $this->db->from('mob_number');
      $this->db->where('c_id',$c_id);
      if($query1=$this->db->get()){
          $n=$query1->num_rows();
          if($n==1){
            $m1=(array)$query1->first_row();
             if(isset($m1)){
              $m1=$m1['m_number'];
             }
             $m2="";
             $m3="";
             $key=array('m1','m2','m3');
             $value=array($m1,$m2,$m3);
             $a=array_combine($key, $value);
             return array_merge($query,$a);
          }
          else if($n==2){
            $m1=(array)$query1->first_row();
             if(isset($m1)){
              $m1=$m1['m_number'];
             }
             $m2=(array)$query1->next_row();
             if(isset($m2)){
                $m2=$m2['m_number'];
             }
             $m3="";
             $key=array('m1','m2','m3');
             $value=array($m1,$m2,$m3);
             $a=array_combine($key, $value);
             return array_merge($query,$a);
          }
          else if($n==3){
            $m1=(array)$query1->first_row();
             if(isset($m1)){
              $m1=$m1['m_number'];
             }
             $m2=(array)$query1->next_row();
             if(isset($m2)){
                $m2=$m2['m_number'];
             }
             $m3=(array)$query1->next_row();
             if(isset($m3)){
                $m3=$m3['m_number'];
             }
             $key=array('m1','m2','m3');
             $value=array($m1,$m2,$m3);
             $a=array_combine($key, $value);
             return array_merge($query,$a);
          } 
          else{
             $m1="";
             $m2="";
             $m3="";
             $key=array('m1','m2','m3');
             $value=array($m1,$m2,$m3);
             $a=array_combine($key, $value);
             return array_merge($query,$a);
          } 
      }
      else{
        return false;
      }
    }

    public function cords($img_id){
      $this->db->select('*');
      $this->db->from('cordinate');
      $this->db->where('img_id',$img_id);
      if($query=$this->db->get()){
          return $query->result();
      }
      else{
        return false;
      }
    }

    public function addcord(){
      $cor_l1=$this->input->post('cor_l1');
      $cor_l2=$this->input->post('cor_l2');
      $cor_r1=$this->input->post('cor_r1');
      $cor_r2=$this->input->post('cor_r2');
      $img_id=$this->input->post('img_id');
      $c_id=$this->input->post('c_id');
      $url=$this->input->post('url');
      $data = array(
              'cor_l1' => $cor_l1,
              'cor_l2' =>$cor_l2,
              'cor_r1' => $cor_r1,
              'cor_r2' => $cor_r2,
              'img_id' => $img_id,
              'u_c_id' => $c_id,
              'url' => $url
            );

       $this->db->insert('cordinate',$data);
       return $data;

    }

    public function view($c_id){
      $this->db->select('t1.front_i,t1.back_i,t1.c_name,t1.con_number,t2.img_id,t2.cor_l1,t2.cor_l2,t2.cor_r1,t2.cor_r2,t2.url,t2.u_c_id');
        $this->db->from('ucard as t1');
        $this->db->where('c_id',$c_id);
        $this->db->where('status',1);
        $this->db->join('cordinate as t2','t1.c_id=t2.u_c_id','LEFT');
        $query=$this->db->get();
      if($query->num_rows()>0){
        return $query->result();
      }else{
        return false;
      }
    }

    public function u_card_entry(){
      $c_name=$this->input->post('c_name');
      $con_number=$this->input->post('con_number');

      $config['upload_path'] = './assets/upload/card';
      $config['allowed_types'] = 'gif|jpg|png|jpeg';
      $config['max_size'] = '2048000'; // max size in KB
      $config['max_width'] = '20000'; //max resolution width
      $config['max_height'] = '20000';  //max resolution height
      $this->load->library('upload', $config);
      if($this->upload->do_upload('front_i')){
        $data_i=array('upload_data' => $this->upload->data());
      }

      $config1['upload_path'] = './assets/upload/card';
      $config1['allowed_types'] = 'gif|jpg|png|jpeg';
      $config1['max_size'] = '2048000'; // max size in KB
      $config1['max_width'] = '20000'; //max resolution width
      $config1['max_height'] = '20000';  //max resolution height
      $this->load->library('upload', $config1);
      if($this->upload->do_upload('back_i')){
        $data_i1=array('upload_data' => $this->upload->data());
      }

      $data = array(
              'c_name' => $c_name,
              'u_id' =>$_SESSION['u_id'],
              'con_number' => $con_number,
              'front_i' => $data_i['upload_data']['file_name'],
              'back_i' => $data_i1['upload_data']['file_name']
            );

      $this->db->insert('ucard',$data);
      return $data;
    }

    public function new_card_entry(){
      $f_name=$this->input->post('f_name');
      $m_name=$this->input->post('m_name');
      $l_name=$this->input->post('l_name');
      $o_name=$this->input->post('o_name');
      $job_title=$this->input->post('job_title');
      $address=$this->input->post('address');
      $web_url=$this->input->post('web_url');
      $twitter_url=$this->input->post('twitter_url');
      $facebook_url=$this->input->post('facebook_url');
      $insta_url=$this->input->post('insta_url');
      $linkedin_url=$this->input->post('linkedin_url');
      $whatsapp=$this->input->post('whatsapp'); 
      $email=$this->input->post('email');
      $youtube_url=$this->input->post('youtube_url');
      $summary=$this->input->post('summary');
      $config['upload_path'] = './assets/upload';
      $config['allowed_types'] = 'gif|jpg|png|jpeg';
      $config['max_size'] = '2048000'; // max size in KB
      $config['max_width'] = '20000'; //max resolution width
      $config['max_height'] = '20000';  //max resolution height
      $this->load->library('upload', $config);
      if($this->upload->do_upload('logo_i')){
        $data_i=array('upload_data' => $this->upload->data());
      }
      $config1['upload_path'] = './assets/upload/video';
      $config1['allowed_types'] = '*';
      $config1['max_size'] = '204800000000'; // max size in KB
      $config1['overwrite'] = FALSE;
      $config1['remove_spaces'] = TRUE;
      $this->load->library('upload', $config1);
      $this->upload->initialize($config1);
      if($this->upload->do_upload('i_video')){
         $data_v=array('upload_data' => $this->upload->data());
      }
      $card_d=$this->input->post('card_d');
      $data = array(
              'u_id ' => $_SESSION['u_id'],
              'f_name' => $f_name,
              'm_name' => $m_name,
              'l_name' => $l_name,
              'o_name' => $o_name,
              'job_title' => $job_title,
              'address' => $address,
              'web_url' => $web_url,
              'twitter_url' => $twitter_url,
              'facebook_url' => $facebook_url,
              'insta_url' => $insta_url,
              'linkedin_url' => $linkedin_url,
              'whatsapp' => $whatsapp,
              'email' => $email,
              'youtube_url' => $youtube_url,
              'summary' => $summary,
              'logo_i' => $data_i['upload_data']['file_name'],
              'i_video' => $data_v['upload_data']['file_name'],
              'card_d_name' =>$card_d
         );
        $this->db->insert('card',$data);
        $c_id=$this->db->insert_id();
        $m=$_POST['mobile'];
        for($i=0; $i<count($m); $i++){
          if(!empty($m[$i])){
            $mobile=$m[$i];
            $d_m= array(
                    'm_number' =>$mobile,
                     'c_id' =>$c_id
            );
            $this->db->insert('mob_number',$d_m);
          }
        }
        $data1=array(
                    'card_d_name' =>$card_d,
                    'c_id' =>$c_id
                  );
        return $data1;
    }

    public function getCard($c_id){
      $query = $this->db->get_where('card',array('c_id'=>$c_id));
      $query=(array)$query->row_array();
      $this->db->select('m_number');
      $this->db->from('mob_number');
      $this->db->where('c_id',$c_id);
      if($query1=$this->db->get()){
          $n=$query1->num_rows();
          if($n==1){
            $m1=(array)$query1->first_row();
             if(isset($m1)){
              $m1=$m1['m_number'];
             }
             $m2="";
             $m3="";
             $key=array('m1','m2','m3');
             $value=array($m1,$m2,$m3);
             $a=array_combine($key, $value);
             return array_merge($query,$a);
          }
          else if($n==2){
            $m1=(array)$query1->first_row();
             if(isset($m1)){
              $m1=$m1['m_number'];
             }
             $m2=(array)$query1->next_row();
             if(isset($m2)){
                $m2=$m2['m_number'];
             }
             $m3="";
             $key=array('m1','m2','m3');
             $value=array($m1,$m2,$m3);
             $a=array_combine($key, $value);
             return array_merge($query,$a);
          }
          else if($n==3){
            $m1=(array)$query1->first_row();
             if(isset($m1)){
              $m1=$m1['m_number'];
             }
             $m2=(array)$query1->next_row();
             if(isset($m2)){
                $m2=$m2['m_number'];
             }
             $m3=(array)$query1->next_row();
             if(isset($m3)){
                $m3=$m3['m_number'];
             }
             $key=array('m1','m2','m3');
             $value=array($m1,$m2,$m3);
             $a=array_combine($key, $value);
             return array_merge($query,$a);
          } 
          else{
             $m1="";
             $m2="";
             $m3="";
             $key=array('m1','m2','m3');
             $value=array($m1,$m2,$m3);
             $a=array_combine($key, $value);
             return array_merge($query,$a);
          } 
      }
      else{
        return false;
      }
    }

    public function updatecard($c_id){
      $f_name=$this->input->post('f_name');
      $m_name=$this->input->post('m_name');
      $l_name=$this->input->post('l_name');
      $o_name=$this->input->post('o_name');
      $job_title=$this->input->post('job_title');
      $address=$this->input->post('address');
      $web_url=$this->input->post('web_url');
      $twitter_url=$this->input->post('twitter_url');
      $facebook_url=$this->input->post('facebook_url');
      $insta_url=$this->input->post('insta_url');
      $linkedin_url=$this->input->post('linkedin_url');
      $whatsapp=$this->input->post('whatsapp'); 
      $email=$this->input->post('email');
      $youtube_url=$this->input->post('youtube_url');
      $summary=$this->input->post('summary');
      $config['upload_path'] = './assets/upload';
      $config['allowed_types'] = 'gif|jpg|png|jpeg';
      $config['max_size'] = '2048000'; // max size in KB
      $config['max_width'] = '20000'; //max resolution width
      $config['max_height'] = '20000';  //max resolution height
      $this->load->library('upload', $config);
      if($this->upload->do_upload('logo_i')){
        $data_i=array('upload_data' => $this->upload->data());
      }
      $config1['upload_path'] = './assets/upload/video';
      $config1['allowed_types'] = '*';
      $config1['max_size'] = '204800000000'; // max size in KB
      $config1['overwrite'] = FALSE;
      $config1['remove_spaces'] = TRUE;
      $this->load->library('upload', $config1);
      $this->upload->initialize($config1);
      if($this->upload->do_upload('i_video')){
         $data_v=array('upload_data' => $this->upload->data());
      }
      $this->db->set('f_name',$f_name);
      $this->db->set('m_name',$m_name);
      $this->db->set('l_name',$l_name);
      $this->db->set('o_name',$o_name);
      $this->db->set('job_title',$job_title);
      $this->db->set('address',$address);
      $this->db->set('web_url',$web_url);
      $this->db->set('twitter_url',$twitter_url);
      $this->db->set('facebook_url',$facebook_url);
      $this->db->set('insta_url',$insta_url);
      $this->db->set('linkedin_url',$linkedin_url);
      $this->db->set('whatsapp',$whatsapp);
      $this->db->set('email',$email);
      $this->db->set('youtube_url',$youtube_url);
      $this->db->set('summary',$summary);
      if(isset($data_i['upload_data']['file_name'])){
        $this->db->set('logo_i',$data_i['upload_data']['file_name']);  
      }
      if(isset($data_v['upload_data']['file_name'])){
        $this->db->set('i_video',$data_v['upload_data']['file_name']);
      }
      $this->db->where('c_id',$c_id);
      $this->db->update('card');
      
      $this->db->delete('mob_number', array('c_id' => $c_id)); 
      $m1=$this->input->post('mobile1');
      if(!empty($m1)){
        $d_m= array(
                    'm_number' =>$m1,
                     'c_id' =>$c_id
            );
            $this->db->insert('mob_number',$d_m);
      }
      $m2=$this->input->post('mobile2');
      if(!empty($m2)){
        $d_m= array(
                    'm_number' =>$m2,
                     'c_id' =>$c_id
            );
            $this->db->insert('mob_number',$d_m);
      }
      $m3=$this->input->post('mobile3');
      if(!empty($m3)){
        $d_m= array(
                    'm_number' =>$m3,
                     'c_id' =>$c_id
            );
            $this->db->insert('mob_number',$d_m);
      }
    }

    public function deletecard($c_id){
      $this->db->delete('card',array('c_id'=>$c_id));
    }

    public function acard($c_id){
      $this->db->set('status',1);
      $this->db->where('c_id',$c_id);
      $this->db->update('ucard');
    }

    public function dcard($c_id){
      $this->db->delete('ucard',array('c_id'=>$c_id));
    }
  }
?>