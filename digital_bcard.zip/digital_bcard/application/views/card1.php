<?php include('header.php')?>


<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css">

<script type="text/javascript">
  $(document).ready(function() { 
    $(".btn-pref .btn").click(function () {
    $(".btn-pref .btn").removeClass("btn-primary").addClass("btn-default");
    // $(".tab").addClass("active"); // instead of this do the below 
    $(this).removeClass("btn-default").addClass("btn-primary");   
    });
  });
</script>

<style type="text/css">
  /* USER PROFILE PAGE */
 .card {
    padding: 30px;
    background-color: rgba(214, 224, 226, 0.2);
    -webkit-border-top-left-radius:5px;
    -moz-border-top-left-radius:5px;
    border-top-left-radius:5px;
    -webkit-border-top-right-radius:5px;
    -moz-border-top-right-radius:5px;
    border-top-right-radius:5px;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
}
.card.hovercard {
    position: relative;
    padding-top: 0;
    overflow: hidden;
    text-align: center;
    background-color: #fff;
    background-color: rgba(255, 255, 255, 1);
}
.card.hovercard .card-background {
    height: 130px;
}
.card-background img {
    -webkit-filter: blur(25px);
    -moz-filter: blur(25px);
    -o-filter: blur(25px);
    -ms-filter: blur(25px);
    filter: blur(25px);
    margin-left: -100px;
    margin-top: -200px;
    min-width: 130%;
}
.card.hovercard .useravatar {
    position: absolute;
    top: 15px;
    left: 0;
    right: 0;
}
.card.hovercard .useravatar img {
    width: 100px;
    height: 100px;
    max-width: 100px;
    max-height: 100px;
    -webkit-border-radius: 50%;
    -moz-border-radius: 50%;
    border-radius: 50%;
    border: 5px solid rgba(255, 255, 255, 0.5);
}
.card.hovercard .card-info {
    position: absolute;
    bottom: 14px;
    left: 0;
    right: 0;
}
.card.hovercard .card-info .card-title {
    padding:0 5px;
    font-size: 20px;
    line-height: 1;
    color: #262626;
    background-color: rgba(255, 255, 255, 0.1);
    -webkit-border-radius: 4px;
    -moz-border-radius: 4px;
    border-radius: 4px;
}
.card.hovercard .card-info {
    overflow: hidden;
    font-size: 12px;
    line-height: 20px;
    color: #737373;
    text-overflow: ellipsis;
}
.card.hovercard .bottom {
    padding: 0 20px;
    margin-bottom: 17px;
}
.btn-pref .btn {
    -webkit-border-radius:0 !important;
}
#p1{
  word-break: break-all;
}
</style>
<script>
$(document).ready(function(){
  $('[data-toggle="tooltip"]').tooltip();   
});
</script>

<section style="margin-left: 400px;margin-top: 110px;">
<?php extract($user); ?>
  <center>
<div class="col-lg-6 col-sm-6" >
    <div class="card hovercard">
        <div class="card-background">
            <img class="card-bkimg" alt="" src="<?=base_url();?>assets/upload/<?php echo $logo_i ;?>">
        </div>
        <div class="useravatar">
            <img alt="" src="<?=base_url();?>assets/upload/<?php echo $logo_i; ?>">
        </div>
        <div class="card-info"> <span class="card-title"><?php echo $f_name." ".$l_name;?></span>
        </div>
    </div>
    <div class="btn-pref btn-group btn-group-justified btn-group-lg" role="group" aria-label="...">
        <div class="btn-group" role="group">
            <button type="button" id="stars" class="btn btn-primary" href="#tab1" data-toggle="tab"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>
                <div class="hidden-xs">Profile</div>
            </button>
        </div>
        <div class="btn-group" role="group">
            <button type="button" id="favorites" class="btn btn-default" href="#tab2" data-toggle="tab"><span class="glyphicon glyphicon-briefcase" aria-hidden="true"></span>
                <div class="hidden-xs">Work Detail</div>
            </button>
        </div>
        <div class="btn-group" role="group">
            <button type="button" id="favorites" class="btn btn-default" href="#tab3" data-toggle="tab"><span class="glyphicon glyphicon-play-circle" aria-hidden="true"></span>
                <div class="hidden-xs">Video</div>
            </button>
        </div>
        <div class="btn-group" role="group">
            <button type="button" id="following" class="btn btn-default" href="#tab4" data-toggle="tab"><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span>
                <div class="hidden-xs">Contact</div>
            </button>
        </div>
    </div>

        <div class="well">
      <div class="tab-content">
        <div class="tab-pane fade in active" id="tab1">
          <b><h4>About me: </h4></b>
          <p id="p1"><?php echo $summary; ?></p>
          <b><h4>Address: </h4></b>
          <p id="p1"><?php echo $address; ?></p>
        </div>
        <div class="tab-pane fade in" id="tab2">
          <p class="title"><?php echo $job_title." at ".$o_name;?></p>
        </div>
        <div class="tab-pane fade in" id="tab3">
          <center><video width="350" height="225" controls>
          <source src="<?=base_url();?>assets/upload/video/<?php echo $i_video;?>" type="video/mp4"></video></center>
        </div>
        <div class="tab-pane fade in" id="tab4">
          <b><h4>Contact Us: </h4></b>
          <p id="p1"><?php echo $m1;?></p>
          <p id="p1"><?php echo $m2;?></p>
          <p id="p1"><?php echo $m3;?></p>
          <center>
          <a href="<?php echo $web_url;?>" data-toggle="tooltip" title="website" target="_blank"><i class="fas fa-search"></i></a>
          <a href="<?php echo $twitter_url?>" data-toggle="tooltip" title="twitter" target="_blank"><i class="fab fa-twitter"></i></a> 
          <a href="<?php echo $facebook_url;?>" target="_blank"><i class="fab fa-facebook" data-toggle="tooltip" title="facebook"></i></a>
          <a href="<?php echo $insta_url;?>" target="_blank"><i class="fab fa-instagram" data-toggle="tooltip" title="instagram"></i></a> 
          <a href="<?php echo $linkedin_url;?>" target="_blank"><i class="fab fa-linkedin" data-toggle="tooltip" title="linkedin"></i></a>  
          <a href="https://api.whatsapp.com/send?phone=91<?php echo $whatsapp;?>" data-toggle="tooltip" title="Whatsapp"><i class="fab fa-whatsapp" target="_blank"></i></a> 
          <a href="<?php echo $youtube_url;?>" data-toggle="tooltip" title="Youtube Channel" target="_blank"><i class="fab fa-youtube"></i></a>
          </center>
        </div>
      </div>
    </div>
  </div>
  </center>

</section>

<section style="margin-left: 580px;position: absolute;margin-top: 500px;">
  <a href="<?php echo base_url();?>editcard/<?php echo $c_id; ?>" class="btn btn-success"><span class="glyphicon glyphicon-edit"></span> Edit</a>
  <a href="<?php echo base_url();?>deletecard/<?php echo $c_id; ?>" class="btn btn-success"><span class="glyphicon glyphicon-trash"></span> Delete</a>
</section>

