<?php include('header.php')?>
<!--
End Fixed Navigation
==================================== -->

<!-- Start Pricing section
		=========================================== -->
	<section class="pricing-table " id="pricing">
		<div class="container">
			<div class="row">
				
				<!-- section title -->
			    <div class="title title-white text-center " >
		        	<h2>Our Greatest Plans</h2>
			        <p>o</p>
			        <div class="border"></div>
			    </div>
			    <!-- /section title -->
				
				<!-- single pricing table -->
				<div class="col-md-4 col-sm-6 col-xs-12" >
					<div class="pricing-item">
						
						<!-- plan name & value -->
						<div class="price-title">
							<h3>Basic</h3>
							<strong class="value">$19</strong>
							<p>Perfect for single freelancers who work by themselves</p>
						</div>
						<!-- /plan name & value -->
						
						<!-- plan description -->
						<ul>
							<li><i class="tf-ion-ios-arrow-forward"></i> 1GB Disk Space</li>
							<li><i class="tf-ion-ios-arrow-forward"></i> 10 Email Account</li>
							<li><i class="tf-ion-ios-arrow-forward"></i> Script Installer</li>
							<li><i class="tf-ion-ios-arrow-forward"></i> 1 GB Storage</li>
							<li><i class="tf-ion-ios-arrow-forward"></i> 2 GB Bandwidth</li>
							<li><i class="tf-ion-ios-arrow-forward"></i> 24/7 Tech Support</li>
						</ul>
						<!-- /plan description -->
						
						<!-- signup button -->
						<a class="btn btn-main" href="#">Buy</a>
						<!-- /signup button -->
						
					</div>
				</div>
				<!-- end single pricing table -->
				
				<!-- single pricing table -->
				<div class="col-md-4 col-sm-6 col-xs-12  "  >
					<div class="pricing-item">
					
						<!-- plan name & value -->
						<div class="price-title">
							<h3>Standard</h3>
							<strong class="value">$39</strong>
							<p>Suitable for small businesses with up to 5 employees</p>
						</div>
						<!-- /plan name & value -->
						
						<!-- plan description -->
						<ul>
							<li><i class="tf-ion-ios-arrow-forward"></i> 1GB Disk Space</li>
							<li><i class="tf-ion-ios-arrow-forward"></i> 50 Email Account</li>
							<li><i class="tf-ion-ios-arrow-forward"></i> Script Installer</li>
							<li><i class="tf-ion-ios-arrow-forward"></i> 1 GB Storage</li>
							<li><i class="tf-ion-ios-arrow-forward"></i> 10 GB Bandwidth</li>
							<li><i class="tf-ion-ios-arrow-forward"></i> 24/7 Tech Support</li>
						</ul>
						<!-- /plan description -->
						
						<!-- signup button -->
						<a class="btn btn-main" href="#">Buy</a>
						<!-- /signup button -->
						
					</div>
				</div>
				<!-- end single pricing table -->
				
				<!-- single pricing table -->
				<div class="col-md-4 col-sm-6 col-xs-12 ">
					<div class="pricing-item">
						
						<!-- plan name & value -->
						<div class="price-title">
							<h3>Enterprise</h3>
							<strong class="value">$59</strong>
							<p>Great for large businesses with more than 5 employees</p>
						</div>
						<!-- /plan name & value -->
						
						<!-- plan description -->
						<ul>
							<li><i class="tf-ion-ios-arrow-forward"></i> Unlimited Disk Space</li>
							<li><i class="tf-ion-ios-arrow-forward"></i> Unlimited Email Account</li>
							<li><i class="tf-ion-ios-arrow-forward"></i> Script Installer</li>
							<li><i class="tf-ion-ios-arrow-forward"></i> Unlimited Storage</li>
							<li><i class="tf-ion-ios-arrow-forward"></i> Unlimited Bandwidth</li>
							<li><i class="tf-ion-ios-arrow-forward"></i> 24/7 Tech Support</li>
						</ul>
						<!-- /plan description -->
						
						<!-- signup button -->
						<a class="btn btn-main" href="#">Buy</a>
						<!-- /signup button -->
						
					</div>
				</div>
				<!-- end single pricing table -->
				
				
			</div>       <!-- End row -->
		</div>   	<!-- End container -->
	</section>   <!-- End section -->
		
<?php include('footer.php')?>