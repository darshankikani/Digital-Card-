<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>bootstrap/css/bootstrap.min.css">
</head>
<body>
<div class="container">
	<div class="row">
		<div><br>
			<table class="table table-bordered table-striped">
				<thead>
					<tr>
						<th>CardID</th>
						<th>UserID</th>
						<th>CardName</th>
						<th>FrontSide</th>
						<th>BackSide</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>
					<?php
					foreach($users as $user){
						?>
						<tr>
							<td><?php echo $user->c_id; ?></td>
							<td><?php echo $user->u_id; ?></td>
							<td><?php echo $user->c_name; ?></td>
							<td><img src="<?=base_url();?>assets/upload/card/<?php echo $user->front_i; ?>" height="200" width="300">&emsp;<a href="<?php echo base_url(); ?>user/editcords/<?php echo $user->front_i; ?>/<?php echo $user->c_id; ?>" class="btn btn-success"><span class="glyphicon glyphicon-edit"></span> Edit</a>  </td>
							<td><img src="<?=base_url();?>assets/upload/card/<?php echo $user->back_i; ?>" height="200" width="300">&emsp;<a href="<?php echo base_url(); ?>user/editcords/<?php echo $user->back_i; ?>/<?php echo $user->c_id; ?>" class="btn btn-success"><span class="glyphicon glyphicon-edit"></span> Edit</a>  </td>
							<td><a href="<?php echo base_url(); ?>user/deletec/<?php echo $user->c_id; ?>" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Delete</a>  </td>
						</tr>
						<?php
					}
					?>
				</tbody>
			</table>
		</div>
	</div>
</div>
</body>
</html>