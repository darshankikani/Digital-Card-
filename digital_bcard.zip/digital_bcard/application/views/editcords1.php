 <script type="text/javascript" src="<?=base_url();?>assets/js/jquery.min.js"></script>
  <script type="text/javascript" src="<?=base_url();?>assets/js/jquery.imgareaselect.pack.js"></script>
  <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/css/imgareaselect-default.css" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" media="screen" title="no title">
<br>
<style type="text/css">
	img {
             border-radius: 30px;
        }
</style>
<center>
<img src="<?=base_url();?>assets/upload/card/<?php echo $img_id; ?>" height="300" width="500" id="d">
<script type="text/javascript">

    $('img#d').imgAreaSelect({
        onSelectEnd: function (img, selection) {
            $('input[name="cor_l1"]').val(selection.x1);
            $('input[name="cor_l2"]').val(selection.y1);
            $('input[name="cor_r1"]').val(selection.x2);
            $('input[name="cor_r2"]').val(selection.y2);            
        }
    });

</script>
</center>
<br>
<div class="container" style="width: 300px">
<form role="form" method="post" action="<?php echo base_url(); ?>addcord">
        <div class="form-group">
            <input class="form-control" id="a1" placeholder="Enter cords of left top (x)" name="cor_l1" type="text" autofocus required>
        </div>     
        <div class="form-group">
            <input class="form-control" id="a2" placeholder="Enter cords of left top (y)" name="cor_l2" type="text" autofocus required>
        </div>
        <div class="form-group">
            <input class="form-control" id="a3" placeholder="Enter cords of right bottom (x)" name="cor_r1" type="text" autofocus required>
        </div>
        <div class="form-group">
            <input class="form-control" id="a4" placeholder="Enter cords of right bottom (y)" name="cor_r2" type="text" autofocus required>
        </div>
        <div class="form-group">
            <input class="form-control" placeholder="Enter url" name="url" type="text" autofocus required>
        </div>
        <input type="hidden" name="img_id" value="<?php echo $img_id; ?>"/>
        <input type="hidden" name="c_id" value="<?php echo $c_id; ?>"/>
        <input class="btn btn-primary btn-block" type="submit" value="submit"/><br>
        <a href="<?php echo base_url(); ?>cancel" class="btn btn-danger btn-block"><span class="glyphicon glyphicon-trash"></span>Cancel</a><br><br>
</form>
</div>