<?php include('header.php')?>

<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css">



<style type="text/css">
  .profile-card {
  background: #FFB300;
  width: 56px;
  height: auto;
  position: relative;
  left: 50%;
  top: 50%;
  z-index: 2;
  margin-top: 70px;
  overflow: hidden;
  opacity: 0;
  -webkit-transform: translate(-50%, -50%);
  transform: translate(-50%, -50%);
  -webkit-border-radius: 50%;
  border-radius: 50%;
  box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.16), 0px 3px 6px rgba(0, 0, 0, 0.23);
  animation: init 0.5s 0.2s cubic-bezier(0.55, 0.055, 0.675, 0.19) forwards, 
             moveDown 1s 0.8s cubic-bezier(0.6, -0.28, 0.735, 0.045) forwards, 
             moveUp 1s 1.8s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards, 
             materia 0.5s 2.7s cubic-bezier(0.86, 0, 0.07, 1) forwards;
}

@keyframes init {
  0% {
    width: 0px;
    height: 0px;
  }
  100% {
    width: 56px;
    height: 56px;
    margin-top: 0px;
    opacity: 1;
  }
}

@keyframes moveDown {
  0% {
    top: 50%;
  }
  50% {
    top: 40%;
  }
  100% {
    top: 100%;
  }
}

@keyframes moveUp {
  0% {
    background: #FFB300;
    top: 100%; 
  }
  50% {
    top: 40%;
  }
  100% {
    top: 50%;
    background: #E0E0E0;
  }
}

@keyframes materia {
  0% {
    background: #E0E0E0;
  }
  50% {
    border-radius: 4px;
  }
  100% {
    width: 440px;
    height: 400px;
    background: #FFFFFF;
    border-radius: 4px;
  }
}

/* this is for card 2 style*/
    body {
    margin:0;
    padding:0;
    font-family:sans-serif;
    background:#fbfbfb;
}
.profile-card {
    padding: 0px;
    position:relative;
    top:60%; 
    left:50%;
    transform:translate(-50%,-50%);
    width:450px;
    height: 380px;
    background:#fff;
    box-shadow:0 20px 50px rgba(0,0,0,.1);
    border-radius:10px;
    transition:0.5s;
}
.profile-card:hover {
    box-shadow:0 30px 70px rgba(0,0,0,.2);
}
.profile-card .box {
    position:relative;
    top:50%;
    left:0;
    transform:translateY(-50%);
    text-align:center;
    padding:0px;
    box-sizing:border-box;
    width:100%;
}
.profile-card .box .img {
    width:120px;
    height:120px;
    margin:0 auto;
    border-radius:50%;
    overflow:hidden;
}
.profile-card .box .img img {
    width:100%;
    height:100%;
}
.profile-card .box h2 {
    font-size:20px;
    color:#262626;
    margin:20px auto;
}
.profile-card .box h2 span {
    font-size:13px;
    background:#e91e63;
    color:#fff;
    display:inline-block;
    padding:4px 5px;
    border-radius:15px;
    
}
.profile-card .box p {
    padding:10px;
    color:#262626;
    word-break: break-all;
}
.profile-card .box span {
    display:inline-flex;
}
.profile-card .box ul {
    margin:0;
    padding:0;
}
.profile-card .box ul li {
    list-style:none;
    float:left;
}
.profile-card .box ul li a {
    display:block;
    color:#aaa;
    margin:0 10px;
    font-size:20px;
    transition:0.5s;
    text-align:center;
}
.profile-card .box ul li:hover a {
    color:#e91e63;
    transform:rotateY(360deg);
}

</style>


<!------ Include the above in your HEAD tag ---------->
<section style="margin-left: 0px;margin-top: 300px;">
  <?php extract($user); ?>
<aside class="profile-card" >


    <div class="box" style="height: 100%">
        <div class="img" style ="margin-top: 5px">
            <img src="<?=base_url();?>assets/upload/<?php echo $logo_i; ?>">
        </div>
        <h2><?php echo $f_name." ".$l_name;?><br><span><?php echo $job_title." at ".$o_name;?></span></h2>
        <p><?php echo $summary;?></p>
        <span>
            <ul>
              <hr>
              <b>Contact Us</b><br>
                <li><a href="<?php echo $web_url;?>" target="_blank"><i class="fas fa-search" aria-hidden="true"></i></a></li>
                <li><a href="<?php echo $facebook_url;?>" target="_blank"><i class="fab fa-facebook" aria-hidden="true"></i></a></li>
                <li><a href="<?php echo $twitter_url;?>" target="_blank"><i class="fab fa-twitter" aria-hidden="true"></i></a></li>
                <li><a href="<?php echo $linkedin_url;?>" target="_blank"><i class="fab fa-linkedin" aria-hidden="true"></i></a></li>
                <li><a href="<?php echo $insta_url;?>" target="_blank"><i class="fab fa-instagram" aria-hidden="true"></i></a></li>
                <li><a href="https://api.whatsapp.com/send?phone=91<?php echo $whatsapp;?>" target="_blank"><i class="fab fa-whatsapp" aria-hidden="true"></i></a></li>
                <li><a href="<?php echo $youtube_url;?>" target="_blank"><i class="fab fa-youtube" aria-hidden="true"></i></a></li><br/>
                <?php echo $m1."  "; ?>
                <?php echo $m2."  "; ?>
                <?php echo $m3."  "; ?>
            </ul>
        </span>
    </div>

</aside>

</section>

<section style="margin-left: 600px;margin-top: -150px;">
  <a href="<?php echo base_url();?>editcard/<?php echo $c_id; ?>" class="btn btn-success"><span class="glyphicon glyphicon-edit"></span> Edit</a>
  <a href="<?php echo base_url();?>deletecard/<?php echo $c_id; ?>" class="btn btn-success"><span class="glyphicon glyphicon-trash"></span> Delete</a>
</section>
