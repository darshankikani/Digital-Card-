<footer id="footer" class="bg-one">
  <div class="top-footer">
    <div class="container">
      <div class="row">
        <div class="col-sm-3 col-md-3 col-lg-3">
          <h3>about</h3>
          <p>about info</p>
        </div>
        <!-- End of .col-sm-3 -->

        <div class="col-sm-3 col-md-3 col-lg-3">
          <ul>
            <li><h3>Our Services</h3></li>
            <li><a href="#">Graphic Design</a></li>
            <li><a href="#">Web Design</a></li>
            <li><a href="#">Web Development</a></li>
          </ul>
        </div>
        <!-- End of .col-sm-3 -->

        <div class="col-sm-3 col-md-3 col-lg-3">
          <ul>
            <li><h3>Quick Links</h3></li>
            <li><a href="#">Partners</a></li>
            <li><a href="#">About</a></li>
            <li><a href="#">FAQ’s</a></li>
            <li><a href="#">Badges</a></li>
          </ul>
        </div>
        <!-- End of .col-sm-3 -->

        <div class="col-sm-3 col-md-3 col-lg-3">
          <ul>
            <li><h3>Connect with us Socially</h3></li>
            <li><a href="#">Facebook</a></li>
            <li><a href="#">Twitter</a></li>
            <li><a href="#">Youtube</a></li>
            <li><a href="#">Pinterest</a></li>
          </ul>
        </div>
        <!-- End of .col-sm-3 -->

      </div>
    </div> <!-- end container -->
  </div>
  <div class="footer-bottom">
    <h5>Copyright 2019. All rights reserved.</h5>
    <h6>Design and Developed by <a href="https://www.truelinesolution.com/">Trueline Solution</a></h6>
  </div>
</footer> <!-- end footer -->
 
  <!-- Main jQuery -->
    <script src="<?=base_url();?>assets/plugins/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap 3.1 -->
    <script src="<?=base_url();?>assets/plugins/bootstrap/js/bootstrap.min.js"></script>
    <!-- Parallax -->
    <script src="<?=base_url();?>assets/plugins/parallax/jquery.parallax-1.1.3.js"></script>
    <!-- lightbox -->
    <script src="<?=base_url();?>assets/plugins/lightbox2/dist/js/lightbox.min.js"></script>
    <!-- slick Carousel -->
    <script src="<?=base_url();?>assets/plugins/slick-carousel/slick/slick.min.js"></script>
    <!-- Portfolio Filtering -->
    <script src="<?=base_url();?>assets/plugins/mixitup/dist/mixitup.min.js"></script>
    <!-- Smooth Scroll js -->
    <script src="<?=base_url();?>assets/plugins/smooth-scroll/dist/js/smooth-scroll.min.js"></script>
    <script type="text/javascript" src="<?=base_url();?>assets/plugins/revo-slider/js/jquery.themepunch.tools.min.js"></script>
    <script type="text/javascript" src="<?=base_url();?>assets/plugins/revo-slider/js/jquery.themepunch.revolution.min.js"></script>
    <!-- Custom js -->
    <script src="<?=base_url();?>assets/js/script.js"></script>

  