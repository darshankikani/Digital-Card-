<?php include('header.php')?>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" media="screen" title="no title">
<style type="text/css">
#l{
    font-size: 30px;
    font-family: Overpass;
    color: #076F9C;
  }
  </style>
  </head>
  <body>
    <section>
<span>
  <div class="container" style="padding: 100px 0;"><!-- container class is used to centered  the body of the browser with some decent width-->
      <div class="row" ><!-- row class is used for grid system in Bootstrap-->
          <div class="col-md-4 col-md-offset-4"><!--col-md-4 is used to create the no of colums in the grid also use for medimum and large devices-->
          
                  <div class="panel-heading">
                      <center><h3 class="panel-title" id="l">Registration</h3></center>
                  </div>
                  <div class="panel-body">
                  <?php
                  $error_msg=$this->session->flashdata('error_msg');
                  if($error_msg){
                    echo $error_msg;
                  }
                   ?>
                      <form role="form" method="post" action="<?php echo base_url('new_value'); ?>">
                          <fieldset>
                              <div class="form-group">
                                  <input class="form-control" placeholder="UserName" name="u_name" type="text" autofocus required>
                              </div>     
                              <div class="form-group">
                                  <input class="form-control" placeholder="E-Mail" name="email" type="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$"required>
                              </div>
                              <div class="form-group">
                                  <input class="form-control" id="m" placeholder="Password" name="password" type="password"  required>
                              </div>
                              <div class="form-group">
                                  <input class="form-control" id="m1" placeholder="Confirm Password" name="password1" type="password" onblur="myFunction()" required>
                                  <script type="text/javascript">
                                    function myFunction() {
                                       var x = document.getElementById("m").value;
                                       var y = document.getElementById("m1").value;
                                      if (x !== y) {
                                         document.getElementById("m2").innerHTML="Password does not match";
                                      }
                                      else{
                                          document.getElementById("m2").style.visibility="hidden";
                                      }
                                  } 
                                  </script>
                              </div>
                              <div class="form-group" id="m2">
                              </div>
                              <input class="btn btn-lg btn-primary btn-block" type="submit" value="Register" name="register" >
                          </fieldset>
                      </form>
                      <center><b>Already registered ?</b> <br></b><a href="<?php echo base_url('login'); ?>">Login here</a></center>
                  </div>
              </div>
          </div>
      </div>
  </div>
</span>
  </section>

<?php include('footer.php')?>
