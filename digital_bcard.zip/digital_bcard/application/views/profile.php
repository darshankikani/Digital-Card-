<?php include('header.php')?>

<br/><br/>

<section class="profile" style="margin-top: 100px;">
<div class="container">
	<div class="row">
		<div class="col-sm-4 col-sm-offset-4">
			<h3>Edit User Info
			</h3>
			<hr>
			<?php extract($user); ?>
			<form method="POST" action="<?php echo base_url(); ?>update/<?php echo $u_id; ?>">
				<div class="form-group">
					<label>Username:</label>
					<input type="text" class="form-control" value="<?php echo $u_name; ?>" name="u_name">
				</div>
				<div class="form-group">
					<label>Email Address:</label>
					<input type="text" class="form-control" value="<?php echo $email; ?>" name="email">
				</div>
				<div class="form-group">
					<label>Password:</label>
					<input type="text" class="form-control" value="<?php echo $password; ?>" name="password">
				</div>
				<button type="submit" class="btn btn-primary"><span class="glyphicon glyphicon-check"></span> Update</button>
			</form>
		</div>
	</div>
</div>
</section>
<br/><br/>
<?php include('footer.php')?>