<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<?php
    $front=array();
    $back=array();
    array_push($front, $user[0]);
    array_push($back, $user[1]);
    $f=count($front[0][0]);
    $b=count($back[0][0]);
?>
 <style type="text/css">    
        .showSlide {  
            display: none  
        }  
            .showSlide img {  
                width: 100%;  
            }  
        .slidercontainer {  
            max-width: 1000px;  
            position: relative;  
            margin: auto;  
        }  
        .left, .right {  
            cursor: pointer;  
            position: absolute;  
            top: 50%;  
            width: auto;  
            padding: 16px;  
            margin-top: -22px;  
            color: white;  
            font-weight: bold;  
            font-size: 18px;  
            transition: 0.6s ease;  
            border-radius: 0 3px 3px 0;  
        }  
        .right {  
            right: 0;  
            border-radius: 3px 0 0 3px;  
        }  
            .left:hover, .right:hover {  
                background-color: rgba(115, 115, 115, 0.8);  
            }  
        .content {  
            color: #eff5d4;  
            font-size: 30px;  
            padding: 8px 12px;  
            position: absolute;  
            top: 10px;  
            width: 100%;  
            text-align: center;  
        }  
        .active {  
            background-color: #717171;  
        } 
        .button1{
        	background-color: #3071A9;
        	color: white;
        	border-radius: 6px;
        	width: 7em;
        	height: 2em;
        	border: none;
        } 
        img {
             border-radius: 30px;
        }
    </style>  
<br>

<div class="slidercontainer" style="width: 500px; height: 300px;">  
        <div class="showSlide">  
            <img src="<?=base_url();?>assets/upload/card/<?php echo $front[0][0][0]['front_i']; ?>" usemap="#front"> 
                <map name="front" style="backface-visibility: hidden;">
                    <div class="front1"></div>
                    <script type="text/javascript">
                        
                            var f=document.getElementsByClassName("front1");
                            <?php
                             for($i=0;$i<$f;$i++){?>
                                f[0].innerHTML+="<area target=\"_blank\"  href=\"<?php echo $front[0][0][$i]['url']?>\" coords=\"<?php echo $front[0][0][$i]['cor_l1']?>,<?php echo $front[0][0][$i]['cor_l2']?>,<?php echo $front[0][0][$i]['cor_r1']?>,<?php echo $front[0][0][$i]['cor_r2']?>\" style=\"backface-visibility: hidden;\">";   

                                      <?php  } ?>
                            
                    </script>
                </map> 
        </div>  
        <div class="showSlide">  
            <img src="<?=base_url();?>assets/upload/card/<?php echo $back[0][0][0]['back_i']; ?>"usemap="#back">
                <map name="back" style="backface-visibility: hidden;">
                    <div class="back1"></div>
                    <script type="text/javascript">
                        
                            var f=document.getElementsByClassName("back1");
                            <?php
                             for($i=0;$i<$f;$i++){?>
                                f[0].innerHTML+="<area target=\"_blank\"  href=\"<?php echo $back[0][0][$i]['url']?>\" coords=\"<?php echo $back[0][0][$i]['cor_l1']?>,<?php echo $back[0][0][$i]['cor_l2']?>,<?php echo $back[0][0][$i]['cor_r1']?>,<?php echo $back[0][0][$i]['cor_r2']?>\" style=\"backface-visibility: hidden;\">";   

                                      <?php  } ?>
                            
                    </script>
                </map>  
       </div>  
</div>


    <center>
        <!-- Navigation arrows -->  
        <button class="button button1" style="margin-top: -100px;" onclick="nextSlide(1)">Backside</button> 
        <script type="text/javascript">
			$('.button').click(function(){
				var $this= $(this);
				$this.toggleClass('button');
				if($this.hasClass('button')){
					$this.text('Backside');
				}
				else{
					$this.text('Frontside');	
				}
			});
		</script>
    <script type="text/javascript">  
        var slide_index = 1;  
        displaySlides(slide_index);  
  
        function nextSlide(n) {  
            displaySlides(slide_index += n);  
        }   
  
        function displaySlides(n) {  
            var i;  
            var slides = document.getElementsByClassName("showSlide");  
            if (n > slides.length) { slide_index = 1 }  
            if (n < 1) { slide_index = slides.length }  
            for (i = 0; i < slides.length; i++) {  
                slides[i].style.display = "none";  
            }  
            slides[slide_index - 1].style.display = "block";  
        }  
    </script>  

<a download> <button class="button button1" onclick="set_d_det()"> Download </button></a>
</center>
<script type="text/javascript">

function set_d_det(){
	var text = "BEGIN:VCARD\nVERSION:2.1\n";
	
	text += "FN:<?php echo $front[0][0][0]['c_name'];?>\n";
	text += "TEL;WORK;VOICE:<?php echo $front[0][0][0]['con_number'];?>\n";

	text += "END:VCARD";
	var element = document.createElement('a');
    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
    element.setAttribute('download', '<?php echo $front[0][0][0]['c_name']; ?>.vcf');

    element.style.display = 'none';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
}
</script>
<br>
<center>
<section style="position: absolute;margin-left: 600px">
<ul class="share-buttons">
  <li><a href="https://www.facebook.com/sharer/sharer.php?u=&quote=" title="Share on Facebook" target="_blank" onclick="window.open('https://www.facebook.com/sharer/sharer.php?u=' + encodeURIComponent(document.URL) + '&quote=' + encodeURIComponent(document.URL)); return false;"><img alt="Share on Facebook" src="<?=base_url();?>assets/images/Facebook.png" /></a></li>
  <li><a href="https://twitter.com/intent/tweet?source=&text=:%20" target="_blank" title="Tweet" onclick="window.open('https://twitter.com/intent/tweet?text=' + encodeURIComponent(document.title) + ':%20'  + encodeURIComponent(document.URL)); return false;"><img alt="Tweet" src="<?=base_url();?>assets/images/Twitter.png" /></a></li>
  <li><a href="https://plus.google.com/share?url=" target="_blank" title="Share on Google+" onclick="window.open('https://plus.google.com/share?url=' + encodeURIComponent(document.URL)); return false;"><img alt="Share on Google+" src="<?=base_url();?>assets/images/Google+.png" /></a></li>
  <li><a href="http://www.linkedin.com/shareArticle?mini=true&url=&title=&summary=&source=" target="_blank" title="Share on LinkedIn" onclick="window.open('http://www.linkedin.com/shareArticle?mini=true&url=' + encodeURIComponent(document.URL) + '&title=' +  encodeURIComponent(document.title)); return false;"><img alt="Share on LinkedIn" src="<?=base_url();?>assets/images/LinkedIn.png" /></a></li>
   <li><a href="https://api.whatsapp.com/send?text=<?=base_url()?>" target="_blank" data-toggle="tooltip" title="Whatsapp"><img alt="Share on Whatsapp" src="<?=base_url();?>assets/images/whatsapp.png"/></a></li>
</ul>
<style type="text/css">
	ul.share-buttons{
  list-style: none;
  padding: 0;
}

ul.share-buttons li{
  display: inline;
}

ul.share-buttons .sr-only{
  position: absolute;
  clip: rect(1px 1px 1px 1px);
  clip: rect(1px, 1px, 1px, 1px);
  padding: 0;
  border: 0;
  height: 1px;
  width: 1px;
  overflow: hidden;
}
</style>
 
</section>
</center>