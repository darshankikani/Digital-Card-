<?php include('header.php')?>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" media="screen" title="no title">
<style type="text/css">
  #l{
    font-size: 30px;
    font-family: Overpass;
    color: #076F9C;
  }

</style>
  </head>
  <body>
<section class="login-page">
  <div class="container" style="padding: 100px 0;">
    <div class="row">
        <div class="col-md-4 col-md-offset-4">
                <div class="panel-heading">
                    <center><h3 class="panel-title" id="l">Login</h3></center>
                </div>
                <?php
                  $success_msg= $this->session->flashdata('success_msg');
                  $error_msg= $this->session->flashdata('error_msg');
                  if($success_msg){
                    ?>
                    <div class="alert alert-success">
                      <?php echo $success_msg; ?>
                    </div>
                  <?php
                  }
                  if($error_msg){
                    ?>
                    <div class="alert alert-danger">
                      <?php echo $error_msg; ?>
                    </div>
                    <?php
                  }
                  ?>
                  <div class="panel-body">
                    <form role="form" method="post" action="<?php echo base_url('profile_check'); ?>">
                        <fieldset>
                            <div class="form-group" >
                                <input class="form-control" placeholder="E-mail" name="email" type="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$"autofocus required>
                            </div>
                            <div class="form-group">
                                <input class="form-control" id="n" placeholder="Password" name="password" type="password"  required>      
                                <input type="checkbox" onclick="myFunction()">Show Password
                                  <script type="text/javascript">
                                    function myFunction() {
                                       var x = document.getElementById("n");
                                      if (x.type === "password") {
                                         x.type = "text";
                                      } else {
                                          x.type = "password";
                                    }
                                  } 
                                </script>
                            </div>
                            <input class="btn btn-lg btn-primary btn-block" type="submit" value="login" name="login" />
                        </fieldset>
                    </form>
                    <center><hr width=70%></center>
                    <form role="form1" method="post" action="<?php echo base_url('register'); ?>">
                      <fieldset>
                      <input class="btn btn-lg btn-primary btn-block" type="submit" value="Register" id="r"/ >
                        </fieldset>
                      </form>
                </div>
            </div>
    </div>
</div>
</section>
<?php include('footer.php')?>
