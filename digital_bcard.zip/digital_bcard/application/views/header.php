<!DOCTYPE html>
<html class="no-js"> 
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta name="description" content="Bingo One page parallax responsive HTML Template ">
  
  <meta name="author" content="Themefisher.com">

  <title>Digital Bussiness Card</title>

<!-- Mobile Specific Meta
  ================================================== -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <!-- Favicon -->
  <link rel="shortcut icon" type="image/x-icon" href="<?=base_url();?>assets/img/favicon.png" />
  
  <!-- CSS
  ================================================== -->
  <!-- RS5.0 Main Stylesheet -->
  <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/plugins/revo-slider/css/settings.css">
  <!-- RS5.0 Layers and Navigation Styles -->
  <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/plugins/revo-slider/css/layers.css">
  <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/plugins/revo-slider/css/navigation.css">
  <!-- REVOLUTION STYLE SHEETS -->
  <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/plugins/revo-slider/fonts/pe-icon-7-stroke/css/pe-icon-7-stroke.css">
  <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/plugins/revo-slider/fonts/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/plugins/revo-slider/css/settings.css">
  <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/plugins/revo-slider/css/layers.css">
  <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/plugins/revo-slider/css/navigation.css"> 
  <!-- Themefisher Icon font -->
  <link rel="stylesheet" href="<?=base_url();?>assets/plugins/themefisher-font/style.css">
  <!-- bootstrap.min css -->
  <link rel="stylesheet" href="<?=base_url();?>assets/plugins/bootstrap/css/bootstrap.min.css">
  <!-- Lightbox.min css -->
  <link rel="stylesheet" href="<?=base_url();?>assets/plugins/lightbox2/dist/css/lightbox.min.css">
  <!-- Slick Carousel -->
  <link rel="stylesheet" href="<?=base_url();?>assets/plugins/slick-carousel/slick/slick.css">
  <link rel="stylesheet" href="<?=base_url();?>assets/plugins/slick-carousel/slick/slick-theme.css">
  <!-- Main Stylesheet -->
  <link rel="stylesheet" href="<?=base_url();?>assets/css/style.css">

  <!-- Colors -->
  <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/css/colors/blue.css" title="green">
  <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/css/colors/red.css" title="light-red">
  <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/css/colors/blue.css" title="blue">
  <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/css/colors/light-blue.css" title="light-blue">
  <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/css/colors/yellow.css" title="yellow">
  <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/css/colors/light-green.css" title="light-green">
  
</head>

<body id="body">
<!--
Fixed Navigation
==================================== -->
<header class="navigation navbar navbar-fixed-top" style="background-color: #286090;">
   <div class="container">
      <div class="navbar-header">
         <!-- responsive nav button -->
         <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
         <span class="sr-only">Toggle navigation</span>
         <span class="icon-bar"></span>
         <span class="icon-bar"></span>
         <span class="icon-bar"></span>
         </button>
         <!-- /responsive nav button -->
         <!-- logo -->
         <a class="navbar-brand logo" href="<?=base_url('home');?>">
            <img class="logo-default" src="<?=base_url();?>assets/images/logo.png" alt="logo" />
            <img class="logo-white" src="<?=base_url();?>assets/images/logo-white.png" alt="logo" />
         </a>
         <!-- /logo -->
      </div>
      <!-- main nav -->
      <nav class="collapse navbar-collapse navbar-right">
         <ul id="nav" class="nav navbar-nav menu">
              <?php 
                if(isset($_SESSION['u_name']))
                {
                     echo "<li><a href=".base_url('home').">Home</a></li>".
                      "<li><a href=".base_url('home').'#about'.">About Us</a></li>".
                      "<li><a href=".base_url('home').'#services'.">Services</a></li>".
                      "<li><a href=".base_url('home').'#pricing'.">Pricing</a></li>".
                     "<li><a href=".base_url('home').'#contact'.">Contact</a></li>".
                      '<li class="dropdown">'.
                        '<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Cards<span class="caret"></span></a>'.
                        '<ul class="dropdown-menu">'.
                         "<li><a href=".base_url('card').">create Cards</a></li>".
                         "<li><a href=".base_url('uploadcard').">upload Cards</a></li>".
                          "<li><a href=".base_url('view_card').">View Cards</a></li>".
                        '</ul>'.
                      '</li>'.
                      "<li><a href=".base_url('profile').">My Profile</a></li>".
                      "<li><a href=".base_url('logout').">Logout</a></li>";
                }
                else{
                    echo "<li><a href=".base_url('home').">Home</a></li>".
                      "<li><a href=".base_url('home').'#about'.">About Us</a></li>".
                      "<li><a href=".base_url('home').'#services'.">Services</a></li>".
                      "<li><a href=".base_url('home').'#pricing'.">Pricing</a></li>".
                     "<li><a href=".base_url('home').'#contact'.">Contact</a></li>".
                      "<li><a href=".base_url('login').">Login</a></li>";
              }
              ?>
                
         </ul>
      </nav>
      <!-- /main nav -->
   </div>
</header>
