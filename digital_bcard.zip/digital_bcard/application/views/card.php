<?php include('header.php')?>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<link href="https://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootswatch/3.3.7/flatly/bootstrap.min.css">
<link href="<?=base_url();?>assets/images/image-picker/image-picker.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>bootstrap/css/bootstrap.min.css">
<style type="text/css">
    .wizard {
      margin-left: 300px;
      margin-right: 300px;
      background: #fff;
  }

      .wizard .nav-tabs {
          position: relative;
          margin: 40px auto;
          margin-bottom: 0;
          border-bottom-color: #e0e0e0;
      }

      .wizard > div.wizard-inner {
          position: relative;
      }

  .connecting-line {
      height: 2px;
      background: #e0e0e0;
      position: absolute;
      width: 80%;
      margin: 0 auto;
      left: 0;
      right: 0;
      top: 50%;
      z-index: 1;
  }

  .wizard .nav-tabs > li.active > a, .wizard .nav-tabs > li.active > a:hover, .wizard .nav-tabs > li.active > a:focus {
      color: #555555;
      cursor: default;
      border: 0;
      border-bottom-color: transparent;
  }

  span.round-tab {
      width: 70px;
      height: 70px;
      line-height: 70px;
      display: inline-block;
      border-radius: 100px;
      background: #fff;
      border: 2px solid #e0e0e0;
      z-index: 2;
      position: absolute;
      left: 0;
      text-align: center;
      font-size: 25px;
  }
  span.round-tab i{
      color:#555555;
  }
  .wizard li.active span.round-tab {
      background: #fff;
      border: 2px solid #5bc0de;
      
  }
  .wizard li.active span.round-tab i{
      color: #5bc0de;
  }

  span.round-tab:hover {
      color: #333;
      border: 2px solid #333;
  }

  .wizard .nav-tabs > li {
      width: 25%;
  }

  .wizard li:after {
      content: " ";
      position: absolute;
      left: 46%;
      opacity: 0;
      margin: 0 auto;
      bottom: 0px;
      border: 5px solid transparent;
      border-bottom-color: #5bc0de;
      transition: 0.1s ease-in-out;
  }

  .wizard li.active:after {
      content: " ";
      position: absolute;
      left: 46%;
      opacity: 1;
      margin: 0 auto;
      bottom: 0px;
      border: 10px solid transparent;
      border-bottom-color: #5bc0de;
  }

  .wizard .nav-tabs > li a {
      width: 70px;
      height: 70px;
      margin: 20px auto;
      border-radius: 100%;
      padding: 0;
  }

      .wizard .nav-tabs > li a:hover {
          background: transparent;
      }

  .wizard .tab-pane {
      position: relative;
      padding-top: 50px;
  }

  .wizard h3 {
      margin-top: 0;
  }

  @media( max-width : 585px ) {

      .wizard {
          width: 90%;
          height: auto !important;
      }

      span.round-tab {
          font-size: 16px;
          width: 50px;
          height: 50px;
          line-height: 50px;
      }

      .wizard .nav-tabs > li a {
          width: 50px;
          height: 50px;
          line-height: 50px;
      }

      .wizard li.active:after {
          content: " ";
          position: absolute;
          left: 35%;
      }
  }
  </style>
  <script type="text/javascript">
    $(document).ready(function () {
      //Initialize tooltips
      $('.nav-tabs > li a[title]').tooltip();
      
      //Wizard
      $('a[data-toggle="tab"]').on('show.bs.tab', function (e) {

          var $target = $(e.target);
      
          if ($target.parent().hasClass('disabled')) {
              return false;
          }
      });

      $(".next-step").click(function (e) {

          var $active = $('.wizard .nav-tabs li.active');
          $active.next().removeClass('disabled');
          nextTab($active);

      });

      $(".prev-step").click(function (e) {

          var $active = $('.wizard .nav-tabs li.active');
          prevTab($active);

      });
  });

  function nextTab(elem) {
      $(elem).next().find('a[data-toggle="tab"]').click();
  }
  function prevTab(elem) {
      $(elem).prev().find('a[data-toggle="tab"]').click();
  }
</script>

<section style="margin-top: 25px;">
  <div class="container">
  <div class="row">
    <section>
        <div class="wizard">
            <div class="wizard-inner">
                <div class="connecting-line"></div>
                <ul class="nav nav-tabs" role="tablist">

                    <li role="presentation" class="active">
                        <a href="#step1" data-toggle="tab" aria-controls="step1" role="tab" title="Step 1">
                            <span class="round-tab">
                                <i class="glyphicon glyphicon-folder-open"></i>
                            </span>
                        </a>
                    </li>

                    <li role="presentation" class="disabled">
                        <a href="#step2" data-toggle="tab" aria-controls="step2" role="tab" title="Step 2">
                            <span class="round-tab">
                                <i class="glyphicon glyphicon-pencil"></i>
                            </span>
                        </a>
                    </li>

                    <li role="presentation" class="disabled">
                        <a href="#step3" data-toggle="tab" aria-controls="step3" role="tab" title="Step 3">
                            <span class="round-tab">
                                <i class="glyphicon glyphicon-picture"></i>
                            </span>
                        </a>
                    </li>

                    <li role="presentation" class="disabled">
                        <a href="#complete" data-toggle="tab" aria-controls="complete" role="tab" title="Complete">
                            <span class="round-tab">
                                <i class="glyphicon glyphicon-ok"></i>
                            </span>
                        </a>
                    </li>
                </ul>
            </div>

            <form role="form"  method="post" action="<?php echo base_url('new_card'); ?>" enctype="multipart/form-data">
                <div class="tab-content">
                    <div class="tab-pane active" role="tabpanel" id="step1">
                        <h3>Basic Detail</h3>
                          <div class="form-group">
                            <label class="c">First Name:</label>
                            <input id="a1" class="form-control" type="text" name="f_name" placeholder="firstname"/>
                          </div>
                          <div class="form-group">
                            <label class="c">Middle Name:</label>
                            <input id="a1" class="form-control" type="text" name="m_name" placeholder="middlename"/>
                          </div>
                          <div class="form-group">
                            <label class="c">Last Name:</label>
                            <input id="a1" class="form-control" type="text" name="l_name" placeholder="lastname"/>
                          </div>
                          <div class="form-group">
                            <label class="c">Organization Name:</label>
                            <input id="a1" class="form-control" type="text" name="o_name" placeholder="organization name"/>
                          </div>
                          <div class="form-group">
                            <label class="c">Job Title:</label>
                            <input id="a1" class="form-control" type="text" name="job_title" placeholder="job title"/>
                          </div>
                          <div class="form-group">
                            <label class="c">Address:</label>
                            <textarea id="a1" class="form-control" type="textarea" name="address" placeholder="Address" rows="3"></textarea>
                          </div>
                        <ul class="list-inline pull-right">
                            <li><button type="button" class="btn btn-primary next-step">Save and continue</button></li>
                        </ul>
                    </div>
                    <div class="tab-pane" role="tabpanel" id="step2">
                        <h3>Additional Information</h3>
                          <div class="form-group">
                            <label class="c">Website_URL:</label>
                            <input id="a1" class="form-control" type="text" name="web_url" placeholder="Website_URL"/>
                          </div>
                          <div class="form-group">
                            <label class="c">Twitter_URL:</label>
                            <input id="a1" class="form-control" type="text" name="twitter_url" placeholder="twitter_URL"/>
                          </div>
                          <div class="form-group">
                            <label class="c">Facebook_URL:</label>
                            <input id="a1" class="form-control" type="text" name="facebook_url" placeholder="facebook_URL"/>
                          </div>
                          <div class="form-group">
                            <label class="c">Instagram_URL:</label>
                            <input id="a1" class="form-control" type="text" name="insta_url" placeholder="instagram_URL"/>
                          </div>
                          <div class="form-group">
                            <label class="c">Linkedin_URL:</label>
                            <input id="a1" class="form-control" type="text" name="linkedin_url" placeholder="Linkedin_URL"/>
                          </div>
                          <div class="form-group">
                            <label class="c">Whatsapp Number:</label>
                            <input id="a1" class="form-control" type="text" name="whatsapp" placeholder="Whatsapp Number" maxlength="10" />
                          </div>
                          <div class="form-group">
                            <label class="c">Mobile Number:</label>
                            <div class="form-group fieldGroup">
                              <div class="input-group">
                              <input id="a1" class="form-control" type="text" name="mobile[]" placeholder="Mobile Number" maxlength="10" />
                              <div class="input-group-addon">
                                <a href="javascript:void(0)" class="addMore">+</a>
                              </div>
                            </div>
                          </div>

                          <div class="form-group fieldGroupCopy" style="display: none">
                              <div class="input-group">
                              <input id="a1" class="form-control" type="text" name="mobile[]" placeholder="Mobile Number" maxlength="10" />
                              <div class="input-group-addon">
                                <a href="javascript:void(0)" class="remove">-</a>
                              </div>
                            </div>
                          </div>
                            <script type="text/javascript">
                                $(document).ready(function(){
                                //group add limit
                                var maxGroup = 3;
                                //add more fields group
                                $(".addMore").click(function(){
                                    if($('body').find('.fieldGroup').length < maxGroup){
                                        var fieldHTML = '<div class="form-group fieldGroup">'+$(".fieldGroupCopy").html()+'</div>';
                                        $('body').find('.fieldGroup:last').after(fieldHTML);
                                    }else{
                                        alert('Maximum '+maxGroup+' mobile numbers are allowed.');
                                    }
                                });
                                //remove fields group
                                $("body").on("click",".remove",function(){ 
                                    $(this).parents(".fieldGroup").remove();
                                });
                            });
                            </script>
                          </div>
                          <div class="form-group">
                            <label class="c">Email Address:</label>
                            <input id="a1" class="form-control" type="email" name="email" placeholder="Email Address" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" />
                          </div>
                          <div class="form-group">
                            <label class="c">Youtube Channel_URL:</label>
                            <input id="a1" class="form-control" type="text" name="youtube_url" placeholder="Youtube_channel_URL"/>
                          </div>
                          <div class="form-group">
                            <label class="c">Summary:</label>
                            <textarea id="a1" class="form-control" type="text" name="summary" placeholder="Tell me something about yourself (max-200 words)" maxlength="200" rows="3"></textarea>
                          </div>
                          <div class="form-group">
                            <label class="c">Logo:</label>
                            <input id="a1" class="form-control" type="file" name="logo_i" placeholder="Logo" accept="image/*" />
                          </div>
                          <div class="form-group">
                            <label class="c">Intro_video:</label>
                            <input id="a1" class="form-control" type="file" name="i_video" placeholder="Intro_video" accept="video/*" />
                          </div>
                        <ul class="list-inline pull-right">
                            <li><button type="button" class="btn btn-default prev-step">Previous</button></li>
                            <li><button type="button" class="btn btn-primary next-step">Save and continue</button></li>
                        </ul>
                    </div>
                    <div class="tab-pane" role="tabpanel" id="step3">
                        <h3>Select Card Design</h3>
                         <div>
                            <select class="image-picker" name="card_d" style="visibility: hidden;">
                              <optgroup label="  ">
                                <option data-img-src="<?=base_url();?>assets/images/card/card1" value="card1">Card 1</option>
                                <option data-img-src="<?=base_url();?>assets/images/card/card2" value="card2">Card 2</option>
                                <option data-img-src="<?=base_url();?>assets/images/card/card3" value="card3">Card 3</option>
                              </optgroup>
                            </select>
                          </div>
                          <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
                          <script src="<?=base_url();?>assets/images/image-picker/image-picker.js"></script>
                          <script>
                          $(".image-picker").imagepicker({
                                    hide_select : false
                                  })
                          </script>
                          <script type="text/javascript">
                            var _gaq = _gaq || [];
                            _gaq.push(['_setAccount', 'UA-36251023-1']);
                            _gaq.push(['_setDomainName', 'jqueryscript.net']);
                            _gaq.push(['_trackPageview']);

                            (function() {
                              var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
                              ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
                              var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
                            })();
                          </script>
                        <ul class="list-inline pull-right">
                            <li><button type="button" class="btn btn-default prev-step">Previous</button></li>
                            <li><button type="submit" class="btn btn-primary btn-info-full next-step">Save and continue</button></li>
                        </ul>
                    </div>
                    <div class="tab-pane" role="tabpanel" id="complete">
                        <h3>Complete</h3>
                        <p>You have successfully created your card.</p>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </form>
        </div>
    </section>
   </div>
</div>
</section>

<?php include('footer.php')?>