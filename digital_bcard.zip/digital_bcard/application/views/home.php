<?php include('header.php')?>
<section class="hero-area">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="block">
					<h1 class="wow fadeInUp" data-wow-duration=".5s" data-wow-delay=".3s" >Digital Connection <br> Creative Agency</h1>
					<p class="wow fadeInUp" data-wow-duration=".5s" data-wow-delay=".5s">about company</p>
					<ul class="list-inline wow fadeInUp" data-wow-duration=".5s" data-wow-delay=".7s">
						<li>
							<?php 
                			if(isset($_SESSION['u_name']))
                			{
								echo "<a data-scroll href=".base_url('card')." class='btn btn-main'>Create Your Card</a>";
							}
							else{
								echo "<a data-scroll href=".base_url('login')." class='btn btn-main'>Create Your Card</a>";
							}
							?>	
						</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</section>	

<!--
Start About Section
==================================== -->
<section class="about" id="about">
	<div class="container">
		<div class="row">
		
			<!-- section title -->
			<div class="title text-center"  >
				<h2>About Us</h2>
				<p>about section</p>
				<div class="border"></div>
			</div>
			<!-- /section title -->

			<div class="col-md-6">
				<img src="<?=base_url();?>assets/images/about-us.jpg" class="img-responsive" alt="">
			</div>
			<div class="col-md-6">
				<p>about 1</p>
				<p>about 2</p>
				<h4>our works</h4>
				<ul class="feature-list">
					<li> <i class="tf-ion-android-checkmark-circle"></i> Web Development</li>
					<li> <i class="tf-ion-android-checkmark-circle"></i> Application Development</li>
					<li> <i class="tf-ion-android-checkmark-circle"></i> Website Design</li>
					<li> <i class="tf-ion-android-checkmark-circle"></i> UI/UX Design</li>
					<li> <i class="tf-ion-android-checkmark-circle"></i> SEO Service</li>
				</ul>
				<a href="#" class="btn btn-main mt-20">Learn More</a>
			</div>
		</div> 		<!-- End row -->
	</div>   	<!-- End container -->
</section>   <!-- End section -->

<!--
Start Call To Action
==================================== -->
<section class="call-to-action-2 section">
	<div class="container">
		<div class="row">
			<div class="col-md-12 text-center">
				<h2>quotes</h2>
			</div>
		</div> 		<!-- End row -->
	</div>   	<!-- End container -->
</section>   <!-- End section -->

<!--
		Start Counter Section
		==================================== -->
		
		<section  class="counter-wrapper section-sm" >
			<div class="container">
				<div class="row">
					<!-- first count item -->
					<div class="col-md-3 col-sm-6 col-xs-6 text-center " >
						<div class="counters-item">
							<i class="tf-ion-ios-alarm-outline"></i>
							<div>
							    <span class="counter" data-count="150">150</span>
							</div>
							<h3>Happy Clients</h3>
						</div>
					</div>
					<!-- end first count item -->
				
					<!-- second count item -->
					<div class="col-md-3 col-sm-6 col-xs-6 text-center " >
						<div class="counters-item">
							<i class="tf-ion-ios-analytics-outline"></i>
							<div>
							    <span class="counter" data-count="130">130</span>
							</div>
							<h3>Projects completed</h3>
						</div>
					</div>
					<!-- end second count item -->
				
					<!-- third count item -->
					<div class="col-md-3 col-sm-6 col-xs-6 text-center "  >
						<div class="counters-item">
							<i class="tf-ion-ios-compose-outline"></i>
							<div>
							    <span class="counter" data-count="99">99</span>
							</div>
				            <h3>Positive feedback</h3>
							
						</div>
					</div>
					<!-- end third count item -->
					
					<!-- fourth count item -->
					<div class="col-md-3 col-sm-6 col-xs-6 text-center ">
						<div class="counters-item kill-border">
							<i class="tf-ion-ios-bolt-outline"></i>
							<div>
							    <span class="counter" data-count="250">250</span>
							</div>
							<h3>Cups of Coffee</h3>
						</div>
					</div>
					<!-- end fourth count item -->
				</div> 		<!-- end row -->
			</div>   	<!-- end container -->
		</section>   <!-- end section -->

<!-- Start Services Section
		==================================== -->
		
		<section class="services"  id="services">
			<div class="container">
				<div class="row">
					
					<!-- section title -->
					<div class="title text-center" >
						<h2 >Our Services</h2>
						<p>services</p>
						<div class="border"></div>
					</div>
					<!-- /section title -->
					
                    <!-- Single Service Item -->
					<div class="col-md-4 col-sm-6 col-xs-12  no-padding" >
						<div class="service-block color-bg text-center">
							<div class="service-icon text-center">
								<i class="tf-ion-ios-copy-outline"></i>
							</div>
							<h3>WordPress Theme</h3>
							<p>w</p>
						</div>
					</div>
                    <!-- End Single Service Item -->
                    
                    <!-- Single Service Item -->
					<div class="col-md-4 col-sm-6 col-xs-12  no-padding" >
						<div class="service-block text-center">
							<div class="service-icon text-center">
								<i class="tf-ion-ios-alarm-outline"></i>
							</div>
							<h3>Responsive Design</h3>
							<p>r</p>
						</div>
					</div>
                    <!-- End Single Service Item -->
                    
                    <!-- Single Service Item -->
					<div class="col-md-4 col-sm-6 col-xs-12  no-padding"  >
						<div class="service-block color-bg text-center">
							<div class="service-icon text-center">
								<i class="tf-ion-ios-book-outline"></i>
							</div>
							<h3>Media &amp; Advertisement</h3>
							<p>m</p>
						</div>
					</div>
					<!-- End Single Service Item -->
					
					<!-- Single Service Item -->
					<div class="col-md-4 col-sm-6 col-xs-12  no-padding" >
						<div class="service-block  text-center">
							<div class="service-icon text-center">
								<i class="tf-ion-ios-briefcase-outline"></i>
							</div>
							<h3>Graphic Design</h3>
							<p>g</p>
						</div>
					</div>
					<!-- End Single Service Item -->
					
					<!-- Single Service Item -->
					<div class="col-md-4 col-sm-6 col-xs-12  no-padding"  >
						<div class="service-block color-bg text-center">
							<div class="service-icon text-center">
								<i class="tf-ion-ios-crop"></i>
							</div>
							<h3>Apps Development</h3>
							<p>a</p>
						</div>
					</div>
					<!-- End Single Service Item -->
					
					<!-- Single Service Item -->
					<div class="col-md-4 col-sm-6 col-xs-12  no-padding">
						<div class="service-block text-center">
							<div class="service-icon text-center">
								<i class="tf-ion-ios-home-outline"></i>
							</div>
							<h3>Networking</h3>
							<p>n</p>
						</div>
					</div>
					<!-- End Single Service Item -->
						
				</div> 		<!-- End row -->
			</div>   	<!-- End container -->
		</section>   <!-- End section -->


<!-- Start Pricing section
		=========================================== -->
	<section class="pricing-table " id="pricing">
		<div class="container">
			<div class="row">
				
				<!-- section title -->
			    <div class="title title-white text-center " >
		        	<h2>Our Greatest Plans</h2>
			        <p>o</p>
			        <div class="border"></div>
			    </div>
			    <!-- /section title -->
				
				<!-- single pricing table -->
				<div class="col-md-4 col-sm-6 col-xs-12" >
					<div class="pricing-item">
						
						<!-- plan name & value -->
						<div class="price-title">
							<h3>Basic</h3>
							<strong class="value">$19</strong>
							<p>Perfect for single freelancers who work by themselves</p>
						</div>
						<!-- /plan name & value -->
						
						<!-- plan description -->
						<ul>
							<li><i class="tf-ion-ios-arrow-forward"></i> 1GB Disk Space</li>
							<li><i class="tf-ion-ios-arrow-forward"></i> 10 Email Account</li>
							<li><i class="tf-ion-ios-arrow-forward"></i> Script Installer</li>
							<li><i class="tf-ion-ios-arrow-forward"></i> 1 GB Storage</li>
							<li><i class="tf-ion-ios-arrow-forward"></i> 2 GB Bandwidth</li>
							<li><i class="tf-ion-ios-arrow-forward"></i> 24/7 Tech Support</li>
						</ul>
						<!-- /plan description -->
						
						<!-- signup button -->
						<a class="btn btn-main" href="<?=base_url('login')?>">Signup</a>
						<!-- /signup button -->
						
					</div>
				</div>
				<!-- end single pricing table -->
				
				<!-- single pricing table -->
				<div class="col-md-4 col-sm-6 col-xs-12  "  >
					<div class="pricing-item">
					
						<!-- plan name & value -->
						<div class="price-title">
							<h3>Standard</h3>
							<strong class="value">$39</strong>
							<p>Suitable for small businesses with up to 5 employees</p>
						</div>
						<!-- /plan name & value -->
						
						<!-- plan description -->
						<ul>
							<li><i class="tf-ion-ios-arrow-forward"></i> 1GB Disk Space</li>
							<li><i class="tf-ion-ios-arrow-forward"></i> 50 Email Account</li>
							<li><i class="tf-ion-ios-arrow-forward"></i> Script Installer</li>
							<li><i class="tf-ion-ios-arrow-forward"></i> 1 GB Storage</li>
							<li><i class="tf-ion-ios-arrow-forward"></i> 10 GB Bandwidth</li>
							<li><i class="tf-ion-ios-arrow-forward"></i> 24/7 Tech Support</li>
						</ul>
						<!-- /plan description -->
						
						<!-- signup button -->
						<a class="btn btn-main" href="<?=base_url('login')?>">Signup</a>
						<!-- /signup button -->
						
					</div>
				</div>
				<!-- end single pricing table -->
				
				<!-- single pricing table -->
				<div class="col-md-4 col-sm-6 col-xs-12 ">
					<div class="pricing-item">
						
						<!-- plan name & value -->
						<div class="price-title">
							<h3>Enterprise</h3>
							<strong class="value">$59</strong>
							<p>Great for large businesses with more than 5 employees</p>
						</div>
						<!-- /plan name & value -->
						
						<!-- plan description -->
						<ul>
							<li><i class="tf-ion-ios-arrow-forward"></i> Unlimited Disk Space</li>
							<li><i class="tf-ion-ios-arrow-forward"></i> Unlimited Email Account</li>
							<li><i class="tf-ion-ios-arrow-forward"></i> Script Installer</li>
							<li><i class="tf-ion-ios-arrow-forward"></i> Unlimited Storage</li>
							<li><i class="tf-ion-ios-arrow-forward"></i> Unlimited Bandwidth</li>
							<li><i class="tf-ion-ios-arrow-forward"></i> 24/7 Tech Support</li>
						</ul>
						<!-- /plan description -->
						
						<!-- signup button -->
						<a class="btn btn-main" href="<?=base_url('login')?>">Signup</a>
						<!-- /signup button -->
						
					</div>
				</div>
				<!-- end single pricing table -->
				
				
			</div>       <!-- End row -->
		</div>   	<!-- End container -->
	</section>   <!-- End section -->
		

<!-- Start Contact Us
	=========================================== -->		
<section class="contact-us" id="contact">
	<div class="container">
		<div class="row">
			
			<!-- section title -->
			<div class="title text-center" >
				<h2>Get In Touch</h2>
				<p>g</p>
				<div class="border"></div>
			</div>
			<!-- /section title -->
			
			<!-- Contact Details -->
			<div class="contact-details col-md-6 " >
				<h3>Contact Details</h3>
				<p>cd</p>
				<ul class="contact-short-info" >
					<li>
						<i class="tf-ion-ios-home"></i>
						<span>Khaja Road, Bayzid, Chittagong, Bangladesh</span>
					</li>
					<li>
						<i class="tf-ion-android-phone-portrait"></i>
						<span>Phone: +880-31-000-000</span>
					</li>
					<li>
						<i class="tf-ion-android-globe"></i>
						<span>Fax: +880-31-000-000</span>
					</li>
					<li>
						<i class="tf-ion-android-mail"></i>
						<span>Email: hello@meghna.com</span>
					</li>
				</ul>
				<!-- Footer Social Links -->
				<div class="social-icon">
					<ul>
						<li><a href="#"><i class="tf-ion-social-facebook"></i></a></li>
						<li><a href="#"><i class="tf-ion-social-twitter"></i></a></li>
						<li><a href="#"><i class="tf-ion-social-dribbble-outline"></i></a></li>
						<li><a href="#"><i class="tf-ion-social-linkedin-outline"></i></a></li>
					</ul>
				</div>
				<!--/. End Footer Social Links -->
			</div>
			<!-- / End Contact Details -->
				
			<!-- Contact Form -->
			<div class="contact-form col-md-6 " >
				<form id="contact-form" method="post" action="sendmail.php" role="form">
				
					<div class="form-group">
						<input type="text" placeholder="Your Name" class="form-control" name="name" id="name">
					</div>
					
					<div class="form-group">
						<input type="email" placeholder="Your Email" class="form-control" name="email" id="email">
					</div>
					
					<div class="form-group">
						<input type="text" placeholder="Subject" class="form-control" name="subject" id="subject">
					</div>
					
					<div class="form-group">
						<textarea rows="6" placeholder="Message" class="form-control" name="message" id="message"></textarea>	
					</div>
					
					<div id="mail-success" class="success">
						Thank you. The Mailman is on His Way :)
					</div>
					
					<div id="mail-fail" class="error">
						Sorry, don't know what happened. Try later :(
					</div>
					
					<div id="cf-submit">
						<input type="submit" id="contact-submit" class="btn btn-transparent" value="Submit">
					</div>						
					
				</form>
			</div>
			<!-- ./End Contact Form -->
		
		</div> <!-- end row -->
	</div> <!-- end container -->
</section> <!-- end section -->

<?php include('footer.php')?>