<?php include('header.php')?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>bootstrap/css/bootstrap.min.css">
<div class="container" style="margin-top: 100px;">
	<div class="row">
		<div class="col-sm-8 col-sm-offset-2">
			<a href="<?php echo base_url(); ?>card" class="btn btn-primary"><span class="glyphicon glyphicon-plus"></span> Add New Card</a><br><br>
			<table class="table table-striped table-bordered">
				<thead>
					<tr>
						<th>Card Name</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>
					<?php
					foreach($posts as $post){
						?>
						<tr>
							<td><?php echo $post->card_d_name; ?></td>
							<td><a href="<?php echo base_url(); ?><?php echo $post->card_d_name;?>/<?php echo $post->c_id; ?>" class="btn btn-success btn-block"><span class="glyphicon glyphicon-eye-open"></span> View</a></td>
						</tr>
						<?php
					}
					?>
				</tbody>
			</table>
		</div>
	</div>
</div>
</body>
</html>