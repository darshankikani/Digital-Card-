<?php include('header.php')?>

<br/><br/>

<section class="profile" style="margin-top: 100px;">
<div class="container">
	<div class="row">
		<div class="col-sm-4 col-sm-offset-4">
			<form method="POST" action="<?php echo base_url('u_card'); ?>" enctype="multipart/form-data">
				<div class="form-group">
					<label class="c">Front side</label>
                    <input id="a1" class="form-control" type="file" name="front_i" placeholder="Front side" accept="image/*" />
				</div>
				<div class="form-group">
					<label class="c">Back side</label>
                    <input id="a1" class="form-control" type="file" name="back_i" placeholder="Back side" accept="image/*" />
				</div>
				<div class="form-group">
					<label>Card Name</label>
					<input type="text" class="form-control" name="c_name" placeholder="Enter Your Name" />
				</div>
				<div class="form-group">
					<label>Contact Number</label>
					<input type="text" class="form-control" name="con_number" maxlength="10" placeholder="Enter Your Contact Number" />
				</div>
				<button type="submit" class="btn btn-primary"><span></span> Submit</button>
			</form>
		</div>
	</div>
</div>
</section>
<br/><br/>

<?php include('footer.php')?>