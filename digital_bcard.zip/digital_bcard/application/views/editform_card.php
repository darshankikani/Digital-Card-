<?php include('header.php')?>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<link href="https://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>bootstrap/css/bootstrap.min.css">
<div class="container" style="margin-top: 100px;margin-bottom: 50px;">
	<div class="row">
		<div class="col-sm-4 col-sm-offset-4">
			<h3>Edit Card
				<span class="pull-right"><a href="<?php echo base_url();?>/view_card" class="btn btn-primary"><span class="glyphicon glyphicon-arrow-left"></span> Back</a></span>
			</h3>
			<hr>
			<?php extract($user); ?>
			<form method="POST" action="<?php echo base_url(); ?>updatecard/<?php echo $c_id; ?>" enctype="multipart/form-data">
				<div class="form-group">
                    <label class="c">First Name:</label>
                    <input id="a1" class="form-control" type="text" name="f_name" value="<?php echo $f_name; ?>"/>
                </div>
                <div class="form-group">
                    <label class="c">Middle Name:</label>
                    <input id="a1" class="form-control" type="text" name="m_name" value="<?php echo $m_name; ?>"/>
                </div>
                <div class="form-group">
                   <label class="c">Last Name:</label>
                   <input id="a1" class="form-control" type="text" name="l_name" value="<?php echo $l_name; ?>"/>
                </div>
                <div class="form-group">
                   <label class="c">Organization Name:</label>
                   <input id="a1" class="form-control" type="text" name="o_name" value="<?php echo $o_name; ?>"/>
                </div>
                <div class="form-group">
                   <label class="c">Job Title:</label>
                   <input id="a1" class="form-control" type="text" name="job_title" value="<?php echo $job_title; ?>"/>
                </div>
                <div class="form-group">
                   <label class="c">Address:</label>
                   <textarea id="a1" class="form-control" type="textarea" name="address" rows="3"><?php echo $address; ?></textarea>
                </div>
                <div class="form-group">
                    <label class="c">Website_URL:</label>
                    <input id="a1" class="form-control" type="text" name="web_url" value="<?php echo $web_url; ?>"/>
                </div>
                <div class="form-group">
                    <label class="c">Twitter_URL:</label>
                    <input id="a1" class="form-control" type="text" name="twitter_url" value="<?php echo $twitter_url; ?>"/>
                </div>
                <div class="form-group">
                    <label class="c">Facebook_URL:</label>
                    <input id="a1" class="form-control" type="text" name="facebook_url" value="<?php echo $facebook_url; ?>"/>
                </div>
                <div class="form-group">
                    <label class="c">Instagram_URL:</label>
                    <input id="a1" class="form-control" type="text" name="insta_url" value="<?php echo $insta_url; ?>"/>
                </div>
                <div class="form-group">
                    <label class="c">Linkedin_URL:</label>
                    <input id="a1" class="form-control" type="text" name="linkedin_url" value="<?php echo $linkedin_url; ?>"/>
                </div>
                <div class="form-group">
                    <label class="c">Whatsapp Number:</label>
                    <input id="a1" class="form-control" type="text" name="whatsapp" value="<?php echo $whatsapp; ?>" maxlength="10" />
                </div>

                <div class="form-group">
                    <label class="c">Mobile Number:</label>
                        <input id="a1" class="form-control" type="text" name="mobile1" value="<?php echo $m1; ?>" maxlength="10" />
                        <input id="a1" class="form-control" type="text" name="mobile2" value="<?php echo $m2; ?>" maxlength="10" />
                        <input id="a1" class="form-control" type="text" name="mobile3" value="<?php echo $m3; ?>" maxlength="10" />
                </div>

                <div class="form-group">
                    <label class="c">Email Address:</label>
                    <input id="a1" class="form-control" type="email" name="email" value="<?php echo $email; ?>" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" />
                </div>
                <div class="form-group">
                    <label class="c">Youtube Channel_URL:</label>
                    <input id="a1" class="form-control" type="text" name="youtube_url" value="<?php echo $youtube_url; ?>"/>
                </div>
                <div class="form-group">
                    <label class="c">Summary:</label>
                    <textarea id="a1" class="form-control" type="text" name="summary" maxlength="200" rows="3"><?php echo $summary; ?></textarea>
                </div>
                <div class="form-group">
                    <label class="c">Logo:</label>
                    <input id="a1" class="form-control" type="file" name="logo_i" placeholder="Logo" accept="image/*" />
                </div>
                <div class="form-group">
                    <label class="c">Intro_video:</label>
                    <input id="a1" class="form-control" type="file" name="i_video" placeholder="Intro_video" accept="video/*" />
                </div>
				<button type="submit" class="btn btn-success"><span class="glyphicon glyphicon-check"></span> Update</button>
			</form>
		</div>
	</div>
</div>
