<?php

class User extends CI_Controller {

    public function __construct(){
            parent::__construct();
      			$this->load->helper('url');
      	 		$this->load->model('user_model');
            $this->load->library('session');
    }

    public function index(){
      $this->load->view('home');
    }

    public function home(){
    $this->load->view('home');
    }

    public function pricing(){
    $this->load->view('pricing');
    }

    public function register(){
      $this->load->view('register');
    }   

    public function login(){
    $this->load->view('login');
    }

    public function profile_check(){
      $user_login=array(
      'email'=>$this->input->post('email'),
      'password'=>$this->input->post('password')
        );
      $data=$this->user_model->login_user($user_login['email'],$user_login['password']);
          if($data)
          {
           $this->session->set_userdata('u_id',$data['u_id']);
            $this->session->set_userdata('u_name',$data['u_name']);
            $this->session->set_userdata('email',$data['email']);
           // $this->session->set_userdata('password',$data['password']);
            //header('Content-Type: application/json');
           // echo json_encode($data);
          //$this->load->view('user_profile.php');
            if($user_login['email']=='abc@admin.com' && $user_login['password']==12){
              $data['users'] = $this->user_model->fetch_card();
              $this->load->view('admin_approval',$data);
            }
            else{
              $this->profile();
            }
          }
          else{
            $this->session->set_flashdata('error_msg', 'Error occured,Try again.');
            $this->load->view('login');
          }
    }

    public function profile(){
      if(isset($_SESSION['u_name'])){
        $data['user'] = $this->user_model->getUser($_SESSION['u_id']);
            $this->load->view('profile',$data);
      }
      else{
      $user_login=array(
      'email'=>$this->input->post('email'),
      'password'=>$this->input->post('password')
        );
      $data=$this->user_model->login_user($user_login['email'],$user_login['password']);
          if($data)
          {
           $this->session->set_userdata('u_id',$data['u_id']);
            $this->session->set_userdata('u_name',$data['u_name']);
            $this->session->set_userdata('email',$data['email']);
           // $this->session->set_userdata('password',$data['password']);
            //header('Content-Type: application/json');
           // echo json_encode($data);
          //$this->load->view('user_profile.php');
              $data['user'] = $this->user_model->getUser($_SESSION['u_id']);
              $this->load->view('profile',$data);
          }
          else{
            $this->session->set_flashdata('error_msg', 'Error occured,Try again.');
            $this->load->view('login');
          }
        }
    }

    public function my_profile(){
      $data['user'] = $this->user_model->getUser($_SESSION['u_id']);
      $this->load->view('profile',$data);
    }

    public function new_value() {
        $result=$this->input->post('email');
        $this->db->select('*');
        $this->db->from('user');
        $this->db->where('email',$result);
        $query=$this->db->get();
        if($query->num_rows()>0){
          $this->load->view('register');
          echo "User Already Exist!!!";
        }else{
          $data=$this->user_model->new_register_user();
          // header('Content-Type: application/json');
          //  echo json_encode($data);
          $this->load->view('login');
        }    
    }

    public function new_card() {
          $data1=$this->user_model->new_card_entry();
          //header('Content-Type: application/json');
            //echo json_encode($data1);
          //$this->load->view('login');
          $data=$data1['c_id'];
          if($data1['card_d_name']=="card1"){
            $this->card1($data);
          }
          else{
            $this->card2($data); 
          }
    }    
    
    public function logout(){
      $this->session->sess_destroy();
      redirect('home', 'refresh');
      // header('location:'.base_url().$this->home());
    }

    public function card(){
      $this->load->view('card');
    }

    public function card1($data){
      $this->data1['user']=$this->user_model->view_card1($data);
      $this->load->view('card1',$this->data1);
    }

    public function card2($data){
      $this->data1['user']=$this->user_model->view_card1($data);
      $this->load->view('card2',$this->data1);
    }

    public function view_card(){
     // $data=$this->user_model->view_card();
      $this->data['posts']=$this->user_model->view_card();
      $this->load->view('view_card',$this->data);
      //$data1=$this->['posts']['c_id'];  
      //$this->load->view('card_all',$this->data);
    }

    public function uploadcard(){
      $this->load->view('uploadcard');
    }

    public function u_card(){
     $this->data['user']=$this->user_model->u_card_entry();
     $this->load->view('display_card',$this->data);
      //header('Content-Type: application/json');
      //echo json_encode($data);
    }

    public function bussinesscard($c_id){
      $data=$this->user_model->view_card11($c_id);
      $data1=(array)($data[0]);
      $data3=$data1['card_d_name'];
      //$data1=$this->['posts']['c_id'];
          if($data3=="card1"){
            $this->card11($c_id);
          }
          else{
            $this->card22($c_id); 
          }
      //$this->load->view('card_all',$this->data);
    }

    public function card11($data){
      $this->data1['user']=$this->user_model->view_card12($data);
      $this->load->view('card11',$this->data1);
    }

    public function card22($data){
      $this->data1['user']=$this->user_model->view_card12($data);
      $this->load->view('card22',$this->data1);
    }

    public function view($c_id){
      $data1['users']=$this->user_model->view($c_id);
      $data=array();
      $front=array();
      $back=array();
      $total=array("0"=>array(),"1"=>array());
      for($i=0;$i<count($data1['users']);$i++){
        $data[$i]=(array)$data1['users'][$i];
        if($data[$i]['front_i']==$data[$i]['img_id']){
          array_push($front, $data[$i]);
        }
        else if($data[$i]['back_i']==$data[$i]['img_id']){
        array_push($back, $data[$i]);
        }
      }
      array_push($total[0],$front);
      array_push($total[1],$back);

      //print_r($data1['users']['front_i']);
      //var_dump(json_encode($total));
      $t['user']=$total;
      $this->load->view('display',$t);

    }

    public function update($id){
    $user['u_name'] = $this->input->post('u_name');
    $user['password'] = $this->input->post('password');
    $user['email'] = $this->input->post('email');

    $query = $this->user_model->updateuser($user, $id);

    if($query){
      header('location:'.base_url().$this->index());
    }
  }

    public function updatecard($c_id){
      $this->user_model->updatecard($c_id);
      $this->view_card();
  }

    public function editcard($c_id){
      $data['user'] = $this->user_model->getCard($c_id);
      $this->load->view('editform_card', $data);
    }

    public function app_card(){ 
      $data['users'] =$this->user_model->appcard();
      $this->load->view('approved_card', $data);
    }

    public function approvecard($c_id){
      $this->user_model->acard($c_id);
      $data['users'] = $this->user_model->fetch_card();
      $this->load->view('admin_approval',$data);
    }

    public function dismisscard($c_id){
      $this->user_model->dcard($c_id);
      $data['users'] = $this->user_model->fetch_card();
      $this->load->view('admin_approval',$data);
   }

    public function deletecard($c_id){
    $this->user_model->deletecard($c_id);
    $this->view_card();
   }

   public function editcords($img_id,$c_id){
      $data['users']=$this->user_model->cords($img_id);
      if(!empty($data['users'])){
        $this->load->view('editcords',$data);
      }
      else{
        $data1 = array('img_id' => $img_id,
                        'c_id' => $c_id);
        $this->load->view('editcords1',$data1);
      }   
    }

    public function addcord(){
       $data['users']=$this->user_model->addcord();
       $this->editcords($data['users']['img_id'],$data['users']['u_c_id']);
       
    }

    public function cancel(){
      $this->app_card();  
    }

    public function deletec($c_id){
      $this->db->delete('ucard',array('c_id'=>$c_id));
      $this->db->delete('cordinate',array('u_c_id'=>$c_id));
      $this->app_card();     
    }

}
?>


